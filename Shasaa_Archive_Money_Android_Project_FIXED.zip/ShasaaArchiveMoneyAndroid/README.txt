SHASAA ARCHIVE MONEY - ANDROID PROJECT

This is a complete Android WebView project with an offline finance tracker UI.

PROJECT STRUCTURE
- app/ : Android application module
- app/src/main/java/... : Android launcher activity
- app/src/main/assets/index.html : app interface and local data logic
- .github/workflows/android.yml : GitHub Actions workflow to build a debug APK

BUILD APK ON GITHUB
1. Upload the CONTENTS of this project folder to the root of a GitHub repository (not the ZIP file itself).
2. Make sure the .github/workflows/android.yml file is included.
3. Commit the uploaded files to the main branch.
4. Open the repository's Actions tab.
5. Select "Build Shasaa Archive Money APK" and wait for the workflow to finish.
6. Open the completed workflow run and download the artifact named "Shasaa-Archive-Money-debug".
7. Extract the downloaded artifact ZIP to get app-debug.apk, then install it on your Android phone.

NOTES
- The app works offline and stores transaction/goal data locally on the device.
- This starter version does not include cloud sync, bank integration, or online account authentication.
- Debug APK is for personal testing. Keep your GitHub repository private if you prefer not to publish the source.
